var dataRef = new Firebase('https://cm-restaurant.firebaseio.com/vangard');
// var userRef = dataRef.child('user')